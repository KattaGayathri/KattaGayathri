PROJECT TITLE : FARMER FRIENDLY SERVICES 

Steps to execute the files:



Steps to execute the code:

Step1: Create a folder which contains all the files you are working with 
       and open the file in notepad or any other editor.


Step2: Name the working files with .html, .css and .php extensions 
       for html, css and php respectively.
       notepad index.html ,notepad index.css, notepad index.php


Step3: Save images with .png or. Jpeg extension and audio clips with .mp3


Step4: Write or copy the code in the notepad and save it.

Step5:File-> save as
       Save in C:\xampp\htdocs location

Step6:open xaamp,start apache and mysql modules
      Then execute the files in a web browser.

Step7:C:\xampp\htdocs.file.html
      Click on the each webpage you need.